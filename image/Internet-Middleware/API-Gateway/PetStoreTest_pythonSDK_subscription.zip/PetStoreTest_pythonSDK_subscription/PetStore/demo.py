# coding=utf-8

from jdcloud_apim_sdk.core.credential import Credential
from jdcloud_apim_sdk.core.config import Config
from jdcloud_apim_sdk.core.const import SCHEME_HTTPS, SCHEME_HTTP
from client.PetStore_client import *
from apis.get_pet_info_request import *
from apis.create_pet_request import *
from apis.test_function_request import *


if __name__ == "__main__":
    access_key = ''
    secret_key = ''
    credential = Credential(access_key, secret_key)
    # config = Config('xueki79b37y4-test.cn-north-1.jdcloud-api.net', scheme=SCHEME_HTTPS) # 测试环境地址
    # config = Config('xueki79b37y4-preview.cn-north-1.jdcloud-api.net', scheme=SCHEME_HTTPS) # 预发环境地址
    config = Config('xueki79b37y4.cn-north-1.jdcloud-api.net', scheme=SCHEME_HTTPS) # 线上环境地址
    client = PetStoreClient(credential, config)

    parameters = dict()
    body = ''
    header = dict()

    get_pet_info_request = GetPetInfoRequest(parameters= {"petId": 1}, body=None,
                                             header={"jdcloud-apim-subscription-key": ""})
    GetPetInfo_response = client.send(get_pet_info_request)
    print(GetPetInfo_response)

    create_pet_request = CreatePetRequest(parameters=dict(), body={"id":1, "price": 12, "type": "cat"},
                                          header={"jdcloud-apim-subscription-key": ""})
    CreatePet_response = client.send(create_pet_request)
    print(CreatePet_response)

    test_function_request = TestFunctionRequest(parameters=dict(), body=None,
                                                header={"jdcloud-apim-subscription-key": ""})
    TestFunction_response = client.send(test_function_request)
    print(TestFunction_response)

